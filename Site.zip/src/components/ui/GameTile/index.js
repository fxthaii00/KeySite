export { default } from './GameTile';
