export { default } from './StatCard';
