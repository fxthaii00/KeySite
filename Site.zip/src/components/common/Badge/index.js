export { default } from './Badge';
